#include "src/common.h"
#include "src/camera.h"
//--------------------------------------------------------
#include "src/matrix.h"
#include "src/vector.h"

Camera::Camera()
{
	init();
}

Camera::~Camera()
{
}

void Camera::init()
{
	// Test Stuff
	vec3Set(&camData.position,	0.f, 7.f, -9.f);
	vec3Set(&camData.right,		1.f, 0.f, 0.f);
	vec3Set(&camData.up,		0.f, 1.f, 1.f);
	vec3Set(&camData.dir,		0.f, -1.f, 1.f);

	vec3Unit(&camData.dir);
	vec3Unit(&camData.up);
	vec3Unit(&camData.right);

	assert(vec3IsUnit(&camData.dir), 	"camData direction is not a unit vector.\n");
	assert(vec3IsUnit(&camData.up), 	"camData up is not a unit vector.\n");
	assert(vec3IsUnit(&camData.right),	"camData right is not a unit vector.\n");
}

void Camera::tick(float dt)
{
//	camData.position.y += 0.01f;
	vec3 origin;
	vec3Zero(&origin);
	matrix rotMatrix;
	matrixYAxisRot(&rotMatrix, 0.1f);
	matrixVec3Rot(&camData.dir,   &rotMatrix, &camData.dir);
	matrixVec3Rot(&camData.up,	  &rotMatrix, &camData.up);
	matrixVec3Rot(&camData.right, &rotMatrix, &camData.right);
	vec3Unit(&camData.dir);
	vec3Unit(&camData.up);
	vec3Unit(&camData.right);
	lookAt_Track(&origin, 8.f);

}

void Camera::lookAt_Track(vec3* target, float distance)
{
	vec3Cpy(&camData.position, &camData.dir);
	vec3Scale(&camData.position, -distance);
	vec3Add(&camData.position, &camData.position, target);
}

void Camera::lookAt_Pan(vec3* target)
{
	vec3Sub(&camData.dir, target, &camData.position);
	vec3Cross(&camData.right, &camData.dir, &k_vec3_UP);
	vec3Cross(&camData.up, &camData.dir, &camData.right);
	vec3Unit(&camData.dir);
	vec3Unit(&camData.up);
	vec3Unit(&camData.right);
}
