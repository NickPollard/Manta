#ifndef __COMMON_H__
#define __COMMON_H__

#include <float.h>
#include <cstdlib>

// PROFILE_ENABLE: disabled (0), enabled (1), master (2)
#define PROFILE_ENABLE 2

#if PROFILE_ENABLE
//#define MAX_PROFILES 8
#define	profiles(f) \
		f(PROFILE_RENDER) \
		f(PROFILE_RENDER_PREPARE) \
		f(PROFILE_RAYTRACE) \
		f(PROFILE_PROJECTRAY) \
		f(PROFILE_INTERSECT) \
		f(PROFILE_CONTAINS) \
		f(PROFILE_TESTPOLY) \
		f(PROFILE_RENDER_PHASE_1) \
		f(PROFILE_RENDER_PHASE_2) \
		f(PROFILE_RENDER_PHASE_3) \
		f(PROFILE_LIGHT)

#define ENUM_ELEMENT(a)	a,
#define BUILD_ENUM(a)	enum { a(ENUM_ELEMENT) };
#define STRING_VERSION(a)	#a,
#define BUILD_STRINGS(a)	{ a(STRING_VERSION) };
#define	INC(a)				+1
#define COUNT(a)	(0 a(INC))


#define MAX_PROFILES COUNT(profiles)

BUILD_ENUM(profiles)
#if PROFILE_ENABLE == 1
#define PROFILE_BEGIN(a)		profileBegin(a);
#define PROFILE_END(a)			profileEnd(a);
#else
#define PROFILE_BEGIN(a)		/* disabled profile */
#define PROFILE_END(a)			/* disabled profile */
#endif // PROFILE_ENABLE==1
#define PROFILE_MASTER_BEGIN(a)	profileBegin(a);
#define PROFILE_MASTER_END(a)	profileEnd(a);
#else
#define PROFILE_BEGIN(a)		/* disabled profile */
#define PROFILE_END(a)			/* disabled profile */

#define PROFILE_MASTER_BEGIN(a)	/* disabled profile */
#define PROFILE_MASTER_END(a)	/* disabled profile */
#endif // PROFILE_ENABLE

#define SQR(a)		((a) * (a))

#define FLOAT_EPSILON	0.000001f
#define FLOAT_MAX		FLT_MAX 

#define THREEPHASE_RENDER			0
#define TWOPHASE_RENDER				1
#define MULTISAMPLE_ENABLE			0
#define LIGHTING_ENABLE				1
#define LIGHTING_NORMAL_BASED 		1
#define LIGHTING_DISTANCE_BASED 	1
#define LIGHTING_SPECULAR_ENABLED	1
#define LIGHTING_AMBIENT_ENABLED	1

#define RENDER_WIDTH	320
#define RENDER_HEIGHT	240

#define MAX_COLOR_VARIATION_SQUARE	10 

typedef char byte;
typedef char* string;

typedef union
{
	struct
	{
		float x;
		float y;
	};
	float	val[2];
} vec2;

typedef vec2 point2;

typedef union
{
	struct
	{
		float x;
		float y;
		float z;
	};
	struct
	{
		float red;
		float green;
		float blue;
	};
	float	val[3];
} vec3;

typedef vec3 point3;

typedef union
{
	struct
	{
		float x;
		float y;
		float z;
		float w;
	};
	struct
	{
		float red;
		float green;
		float blue;
		float alpha;
	};
	float	val[4];
} vec4;

typedef struct raydef_s
{
	point3 point;
	vec3 direction;
	float xgradient;
	float ygradient;
} raydef;

typedef struct color3i_s
{
	int red;
	int green;
	int blue;
} color3i;

typedef vec3 color3f;

typedef union matrix_s
{
	float	val[4][4];
	vec4	rows[4];
} matrix;

typedef struct polygon_s
{
	point3*	point[3];
	int		pointIndex[3];
	vec3	normal;
	color3f	color;
	// D
	float	d;
	float	minZ;
	float	minxgrad;
	float	maxxgrad;
	float	minygrad;
	float	maxygrad;
} polygon;

typedef struct polygon2_s
{
	point2	point[3];
} poly2d;

typedef struct light_s
{
	point3	position;
	color3f	color;
} light;

typedef struct cameraData_s
{
	point3	position;
	vec3	dir;
	vec3	up;
	vec3	right;
} cameraData;

typedef struct model_s
{
	point3	position;
	matrix	rotation;
	int		vertexCount;
	int		vertexIndex;
	int		polyCount;
	int		polyIndex;
	float	minxgrad;
	float	maxxgrad;
	float	minygrad;
	float	maxygrad;
} model;

// Functions

void assert(bool valid, const char* message);
bool floatEq(float f1, float f2);

// --- Color
void colorFloatToInt(color3i* intCol, color3f* floatCol);
void colorIntToFloat(color3f* floatCol, color3i* intCol);
int	 colorIntVariance(color3i* colorA, color3i* colorB);
void colorIntAdd(color3i* dst, color3i* src1, color3i* src2);
void colorIntDivide(color3i* color, int scale);
void colorFloatTrunc(color3f* color);
// --- Profiling
void profileBegin(int index);
void profileEnd(int index);
void dumpProfileTimes();
void newFrame();
unsigned long long rdtsc();

#endif // __COMMON_H__
