#ifndef __RENDERAREA_H__
#define __RENDERAREA_H__

#include <gtkmm/drawingarea.h>

class View;

class RenderArea : public Gtk::DrawingArea
{
    protected:
	// The pixbuf that holds the rendered image
	Glib::RefPtr<Gdk::Pixbuf> image;
	// Rowstride of the pixbuf, used in get/set pixel commands
	int		rowstride;
	// View this renderArea represents
	View*	renderView;

	// Screen centre coordinates
	float	cx;
	float	cy;
	// Screen size properties
	float	imageWidth;
	float	imageHeight;
	float	aspectRatio;

	void init();
	void renderPixel(int x, int y);
	void shouldRayTrace(int x, int y);
	void shouldRayTraceB(int x, int y);
	void setPixel(int x, int y, guint8 red, guint8 green, guint8 blue);
	bool getPixel(color3f* color, int x, int y);
	// Override default signal handler
	virtual bool on_expose_event(GdkEventExpose* event);

    public:
	RenderArea();
	RenderArea(View* inRenderView);
	virtual ~RenderArea();
	
	bool render();
};

#endif // __RENDERAREA_H__
