#include "src/common.h"
#include "src/mantaMgr.h"
//--------------------------------------------------------
#include "src/filemanager_model.h"
#include "src/matrix.h"
#include "src/prop.h"
#include "src/propMgr.h"
#include "src/renderArea.h"
#include "src/scene.h"
#include "src/unittest.h"
#include "src/vector.h"
#include "src/view.h"

#include <gtkmm/main.h>
#include <gtkmm/window.h>

// Global Manager Pointers
FileManager_Model*	modelManager;
FileManager_Scene*	sceneManager;
PropMgr*			propManager;

MantaMgr::MantaMgr()
{
	init();
}

MantaMgr::~MantaMgr()
{
}

void MantaMgr::init()
{
	Glib::signal_idle().connect( sigc::mem_fun(*this, &MantaMgr::tick) );
	modelManager = new FileManager_Model();
	sceneManager = new FileManager_Scene();
	propManager	 = new PropMgr();
}

bool MantaMgr::tick()
{
#if PROFILE_ENABLE
	newFrame();
#endif // PROFILE_ENABLE
	
	float dt = 0.f;

	// Tick Managers
	propManager->tick(dt);
	mantaView->tick(dt);

	// Render the scene
	mantaArea->render();
	return true;
}

void MantaMgr::main(int argc, char** argv)
{
	UnitTest tester;
	tester.TestVectors();

	// Initialise the toolkit
	Gtk::Main kit(argc, argv);

	// Build a window
	Gtk::Window win;
	win.set_default_size(RENDER_WIDTH, RENDER_HEIGHT);
	win.set_title("Manta");

	// Add some models
	mantaScene = sceneManager->LoadScene((string)"assets/scenes/cityscene.scn");

	// Setup a view and a place to render it
	mantaView = new View(mantaScene);
	mantaArea = new RenderArea(mantaView);
	win.add(*mantaArea);
	mantaArea->show();

	// Run the main GTK loop
	Gtk::Main::run(win);
	
#if PROFILE_ENABLE
	dumpProfileTimes();
#endif // PROFILE_ENABLE
}
