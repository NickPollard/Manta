#ifndef __GEOMETRY_H__
#define __GEOMETRY_H__

void	intersect(polygon* poly, raydef* ray, point3* intersectPoint);
bool	polyContainsPoint(polygon* poly, point3* point);
void	flattenPoly(poly2d* flatPoly, polygon* poly, point3* point);
bool	insideFlatPoly(poly2d* flatPoly);
bool	testEdge(poly2d* flatPoly, int index);

//debug

void	debugBuildPoly(polygon* poly, point3* p0, point3* p1, point3* p2, vec3* normal, color3f* color);

#endif // __GEOMETRY_H__
