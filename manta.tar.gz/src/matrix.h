#ifndef __MATRIX_H__
#define __MATRIX_H__

void matrixIdent(matrix* m);
void matrixVec3Rot(vec3* out, matrix* m, vec3* in);
void matrixCpy(matrix* out, matrix* in);
void rotMatrixFromVec3(matrix* out, vec3* dir, vec3* up);
void invRotMatrixFromVec3(matrix* out, vec3* dir, vec3* up);
void matrixYAxisRot(matrix* m, float angle);

#endif // __MATRIX_H__
