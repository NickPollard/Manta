#include "src/common.h"
#include "src/scene.h"
//--------------------------------------------------------
#include "src/geometry.h"
#include "src/matrix.h"
#include "src/vector.h"
#include <math.h>
#include <stdio.h>

Scene::Scene()
{
	init();
}

Scene::~Scene()
{
}

void Scene::init()
{
	vertexCount = 0;
	polyCount = 0;
	modelCount = 0;

#if PROFILE_ENABLE == 1
	totalPolysTested = 0;
	raysTraced = 0;
	planesTested = 0;
#endif // PROFILE_ENABLE == 1
}

int Scene::addVertex(vec3* position)
{
	assert(vertexCount < MAX_SCENE_VERTICES, "Error, attempting to add too many Vertices!\n");
	vec3Cpy(&sceneVertices[vertexCount++], position);
	return vertexCount-1;
}

int Scene::addPolygon(int* inVerts)
{
	assert(polyCount < MAX_SCENE_POLYS, "Error, attempting to add too many Polygons!\n");
	color3f white;
	vec3Set(&white, 1.f, 1.f, 1.f);
	vec3 edgeA, edgeB, normal;
	vec3* verts[3];

	verts[0] = &sceneVertices[inVerts[0]];
	verts[1] = &sceneVertices[inVerts[1]];
	verts[2] = &sceneVertices[inVerts[2]];

	vec3Sub(&edgeA, verts[0], verts[1]);
	vec3Sub(&edgeB, verts[0], verts[2]);

	vec3Cross(&normal, &edgeB, &edgeA);
	vec3Unit(&normal);

	scenePolygons[polyCount].pointIndex[0] = inVerts[0];
	scenePolygons[polyCount].pointIndex[1] = inVerts[1];
	scenePolygons[polyCount].pointIndex[2] = inVerts[2];

	scenePolygons[polyCount].minxgrad = 1.f;
	scenePolygons[polyCount].maxxgrad = -1.f;
	scenePolygons[polyCount].minygrad = 1.f;
	scenePolygons[polyCount].maxygrad = -1.f;

	debugBuildPoly(&scenePolygons[polyCount++], 
					verts[0],
					verts[1],
					verts[2],
					&normal,
					&white);


	return polyCount-1;
}

model* Scene::addModel(vec3* position, int vertexIndex, int vertexCount, int polyIndex, int polyCount)
{
	assert(modelCount < MAX_SCENE_MODELS, "Error, attempting to add too many Models!\n");
	model* newModel = &sceneModels[modelCount++];
	newModel->vertexIndex = vertexIndex;
	newModel->vertexCount = vertexCount;
	newModel->polyCount = polyCount;
	newModel->polyIndex = polyIndex;
	newModel->minxgrad = 1.f;
	newModel->maxxgrad = -1.f;
	newModel->minygrad = 1.f;
	newModel->maxygrad = -1.f;
	matrixIdent(&newModel->rotation);
	vec3 up, dir;
	vec3Set(&up, 1.f, 0.f, 0.f);
	vec3Set(&dir, 0.f, 0.f, 1.f);
	rotMatrixFromVec3(&newModel->rotation, &dir, &up);
	vec3Cpy(&newModel->position, position);
	return newModel;
}

void Scene::rayTrace(color3f* pixCol, raydef* ray)
{
	polygon*	closestPoly  = NULL;
	float		closestZ	 = FLOAT_MAX;
	point3		closestPoint = {{0.f, 0.f, 0.f}};
	// For every Model in the scene
	PROFILE_BEGIN(PROFILE_TESTPOLY)
	for (int i = 0; i < modelCount; i++)
	{
		model* thisModel = &renderModels[i];
		if ((ray->xgradient > thisModel->maxxgrad) || 
			(ray->xgradient < thisModel->minxgrad) || 
			(ray->ygradient > thisModel->maxygrad) || 
			(ray->ygradient < thisModel->minygrad))
		{
			continue;
		}
		// For every Polygon in the Model
		for (int j = 0; j < thisModel->polyCount; j++)
		{
			polygon* thisPoly = &renderPolygons[thisModel->polyIndex + j];
#if PROFILE_ENABLE == 1
			totalPolysTested++;
#endif // PROFILE_ENABLE == 1

			if (thisPoly->minZ < closestZ)	
			{
				if ((ray->xgradient > thisPoly->maxxgrad) || 
					(ray->xgradient < thisPoly->minxgrad) || 
					(ray->ygradient > thisPoly->maxygrad) || 
					(ray->ygradient < thisPoly->minygrad))
				{
					continue;
				}
				point3 intersectPoint;
				// Find point of intersection
				PROFILE_BEGIN(PROFILE_INTERSECT);
				intersect(thisPoly, ray, &intersectPoint);
				PROFILE_END(PROFILE_INTERSECT);
				// If point of intersection closer than closest
				if ((intersectPoint.z < closestZ) && (intersectPoint.z > 0.f))
				{
#if PROFILE_ENABLE == 1
					planesTested++;
#endif // PROFILE_ENABLE == 1
					// 	If point of intersection of plane inside polygon
					PROFILE_BEGIN(PROFILE_CONTAINS);
					if (polyContainsPoint(thisPoly, &intersectPoint))
					{
						closestZ = intersectPoint.z;
						closestPoly = thisPoly;
						vec3Cpy(&closestPoint, &intersectPoint);
					}
					PROFILE_END(PROFILE_CONTAINS);
				}
			}
			else
			{
				break; // for (int j = 0; j < thisModel->polyCount; j++)
			}
		}
	}
#if PROFILE_ENABLE == 1
	raysTraced ++;
#endif // PROFILE_ENABLE == 1
	PROFILE_END(PROFILE_TESTPOLY)
	if (closestPoly)
	{
		PROFILE_BEGIN(PROFILE_LIGHT)
#if LIGHTING_ENABLE
		color3f tmpColor;
		vec3Cpy(&tmpColor, &renderLight.color); 
		vec3 displacement;
		vec3Sub(&displacement, &renderLight.position, &closestPoint);
		float scale = 1.f;
#if LIGHTING_DISTANCE_BASED		
		scale = 1/(vec3Len(&displacement)+1.f);
#endif // LIGHTING_DISTANCE_BASED
#if LIGHTING_NORMAL_BASED
		vec3Unit(&displacement);
		scale *= vec3Dot(&closestPoly->normal, &displacement);
#endif // LIGHTING_NORMAL_BASED
#if LIGHTING_SPECULAR_ENABLED
		vec3 reflection;
		vec3Reflect(&reflection, &displacement, &closestPoly->normal);
		vec3Unit(&reflection);
		vec3Unit(&closestPoint);
		float specular = vec3Dot(&reflection, &closestPoint);
		specular = (-specular * SPECULAR_BRIGHTNESS) - SPECULAR_FALLOFF;
		specular = fmax(0.f, specular);
		scale += specular;
#endif // LIGHTING_SPECULAR_ENABLED
#if LIGHTING_AMBIENT_ENABLED
		scale += AMBIENT_BRIGHTNESS;
#endif // LIGHTING_AMBIENT_ENABLED
		vec3Scale(&tmpColor, scale);
		color3f* pColor = &closestPoly->color;
		tmpColor.x *= pColor->x;
		tmpColor.y *= pColor->y;
		tmpColor.z *= pColor->z;
		colorFloatTrunc(&tmpColor);
		vec3Cpy(pixCol, &tmpColor);
#else
		vec3Cpy(pixCol, &closestPoly->color);
#endif
		PROFILE_END(PROFILE_LIGHT)
		return;
	}
	else
	{
		vec3Set(pixCol, 0.f, 0.f, 0.f);
		return;
	}
}

void Scene::prepareForRender(cameraData* viewCam)
{
	matrix rotMatrix;
	matrixIdent(&rotMatrix);
	invRotMatrixFromVec3(&rotMatrix, &viewCam->dir, &viewCam->up);

	// Translate verts from model space to world space
	for (int i = 0; i < modelCount; i++)
	{
		model* currentModel = &sceneModels[i];
		for (int j = 0; j < currentModel->vertexCount; j++)
		{
			int n = currentModel->vertexIndex + j;
			matrixVec3Rot(&renderVertices[n], &currentModel->rotation, &sceneVertices[n]);
			vec3Add(&renderVertices[n], &renderVertices[n], &currentModel->position);
		}
	}
	// Translate verts from world space to camera space
	for (int j = 0; j < vertexCount; j++)
	{
		vec3Sub(&renderVertices[j], &renderVertices[j], &viewCam->position);
		matrixVec3Rot(&renderVertices[j], &rotMatrix, &renderVertices[j]);
	}
	// Translate Lights
	vec3Sub(&renderLight.position, &sceneLight.position, &viewCam->position);
	matrixVec3Rot(&renderLight.position, &rotMatrix, &renderLight.position);
	vec3Cpy(&renderLight.color, &sceneLight.color);
	// Calculate model render data
	int newPolyIndex = 0;
	for (int i = 0; i < modelCount; i++)
	{
		renderModels[i] = sceneModels[i];
		model* thisModel = &renderModels[i];
		int newPolyCount = 0;
		// For every polygon in each model
		for (int j = 0; j < thisModel->polyCount; j++)
		{
			int n = j + thisModel->polyIndex;
			int m = newPolyCount + newPolyIndex;
			renderPolygons[m] = scenePolygons[n];
			polygon* poly = &renderPolygons[m];
			matrixVec3Rot(&poly->normal, &thisModel->rotation, &poly->normal);
			matrixVec3Rot(&poly->normal, &rotMatrix, &poly->normal);
			poly->point[0] = &renderVertices[poly->pointIndex[0]];
			// Backface Culling
			if (vec3Dot(&poly->normal, poly->point[0]) > 0.f)
			{
				// Cull the face, it's pointing away
				continue; // for (int j = 0; j < thisModel->polyCount; j++)
			}
			poly->point[1] = &renderVertices[poly->pointIndex[1]];
			poly->point[2] = &renderVertices[poly->pointIndex[2]];
			poly->d = vec3Dot(&poly->normal, poly->point[0]);
			poly->minZ = fmin(poly->point[0]->z, fmin(poly->point[1]->z, poly->point[2]->z)); 

			// Calc gradient extents
			for (int k = 0; k < 3; k++)
			{
				float xgrad = poly->point[k]->x / poly->point[k]->z;
				float ygrad = poly->point[k]->y / poly->point[k]->z;
				// Poly
				poly->maxxgrad = (xgrad > poly->maxxgrad) ? xgrad : poly->maxxgrad;
				poly->minxgrad = (xgrad < poly->minxgrad) ? xgrad : poly->minxgrad;
				poly->maxygrad = (ygrad > poly->maxygrad) ? ygrad : poly->maxygrad;
				poly->minygrad = (ygrad < poly->minygrad) ? ygrad : poly->minygrad;
				// Model
				thisModel->maxxgrad = (xgrad > thisModel->maxxgrad) ? xgrad : thisModel->maxxgrad;
				thisModel->minxgrad = (xgrad < thisModel->minxgrad) ? xgrad : thisModel->minxgrad;
				thisModel->maxygrad = (ygrad > thisModel->maxygrad) ? ygrad : thisModel->maxygrad;
				thisModel->minygrad = (ygrad < thisModel->minygrad) ? ygrad : thisModel->minygrad;
			}
			newPolyCount++;
		}
		thisModel->polyIndex = newPolyIndex;
		thisModel->polyCount = newPolyCount;
		newPolyIndex += newPolyCount;
	}
	polyCount = newPolyIndex;
	// Z-ordering (Bubblesort) - PER MODEL
	for (int k = 0; k < modelCount; k++)
	{
		model* thisModel = &renderModels[k];
		for (int i = 0; (i + 1) < thisModel->polyCount; i++)
		{
			for (int j = 0; (j + 1) < (thisModel->polyCount - i); j++)
			{
				int n = thisModel->polyIndex + j;
				// Test n and n+1, maybe swap
				if (renderPolygons[n].minZ > renderPolygons[n+1].minZ)
				{
					//Swap
					polygon slot;
					slot = renderPolygons[n+1];
					renderPolygons[n+1] = renderPolygons[n];
					renderPolygons[n] = slot;
				}
			}
		}
	}
}

void Scene::PrintStats()
{
#if PROFILE_ENABLE == 1
	printf("---------- Scene render stats: -----------\n");
	printf("-- Model Count: %d\n", modelCount);
	printf("-- Poly Count: %d\n", polyCount);
	printf("-- Vertex Count: %d\n", vertexCount);
	printf("------------------------------------------\n");
	printf("-- Total Rays Traced: %d\n", raysTraced);
	printf("-- Total Polygons tested: %d\n", totalPolysTested);
	printf("-- Average Polygons tested per ray %f\n", (float)totalPolysTested/(float)raysTraced);
	printf("-- Total Planes tested for containment: %d\n", planesTested);
	printf("-- Average Planes tested per ray %f\n", (float)planesTested/(float)raysTraced);
#endif // PROFILE_ENABLE == 1
}

void Scene::setLight(vec3* position, color3f* color)
{
	vec3Cpy(&sceneLight.position, position);
	vec3Cpy(&sceneLight.color, color);
}
