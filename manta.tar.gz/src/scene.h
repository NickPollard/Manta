#ifndef __SCENE_H__
#define __SCENE_H__


#define MAX_SCENE_POLYS 1024
#define MAX_SCENE_VERTICES 512
#define	MAX_SCENE_MODELS 8

#define SPECULAR_BRIGHTNESS 0.2f
#define SPECULAR_FALLOFF	0.1f
#define AMBIENT_BRIGHTNESS	0.1f

class Scene
{
	private:
#if PROFILE_ENABLE == 1
	int totalPolysTested;
	int raysTraced;
	int planesTested;
#endif // PROFILE_ENABLE == 1

	protected:
	int polyCount;
	int vertexCount;
	int modelCount;
	// Scene Information
	polygon scenePolygons[MAX_SCENE_POLYS];
	point3	sceneVertices[MAX_SCENE_VERTICES];
	model	sceneModels[MAX_SCENE_MODELS];
	// Frame Information
	polygon renderPolygons[MAX_SCENE_POLYS];
	point3	renderVertices[MAX_SCENE_VERTICES];
	model	renderModels[MAX_SCENE_MODELS];
	// List of lights
	light sceneLight;
	light renderLight;

	public:
		Scene();
		virtual ~Scene();

		void init();
		int		addVertex(vec3* position);
		int		addPolygon(int* inVerts);
		model*	addModel(vec3* position, int vertexIndex, int vertexCount, int polyIndex, int polyCount);
		void	prepareForRender(cameraData* viewCam);
		void	rayTrace(color3f* pixCol, raydef* ray);
		void	PrintStats();

		// Getters'n'Setters
		int getVertexCount() { return vertexCount; }
		int getPolyCount() { return polyCount; }
		void setLight(vec3* position, color3f* color);
};

#endif // __SCENE_H__
