#include "src/common.h"
//--------------------------------------------------------
#include "src/mantaMgr.h"

int main(int argc, char** argv)
{
	MantaMgr theManta;
	theManta.main(argc, argv);
	return 0;
}
