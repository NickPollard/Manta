#include "src/common.h"
#include "src/geometry.h"
//--------------------------------------------------------
#include "src/vector.h"

#include <math.h>
#include <stdio.h>

// Find the point at which a ray intersects a plane, based on a poly
void intersect(polygon* poly, raydef* ray, point3* intersectPoint)
{
	// Assume that ray origin is 0,0,0, as we move the scene in prepareForRender
	float normaldotdirection =	vec3Dot(&poly->normal, &ray->direction);
	float depth = (poly->d) / (normaldotdirection);
	// Ray start is 0,0,0
	vec3Zero(intersectPoint);
	vec3AddScale(intersectPoint, &ray->direction, depth);
	return;
}

bool polyContainsPoint(polygon* poly, point3* point)
{
	// Flatten the polygon, projecting along the dominating axis
	poly2d flatPoly;
	flattenPoly(&flatPoly, poly, point);
	return insideFlatPoly(&flatPoly);
}

void flattenPoly(poly2d* flatPoly, polygon* poly, point3* point)
{
	int dominant;
	// Calculate dominant axis (simplify)
	if (SQR(poly->normal.x) > 0.3f)
		dominant = 0;
	else if (SQR(poly->normal.y) > 0.3f)
		dominant = 1;
	else if (SQR(poly->normal.z) > 0.3f)
		dominant = 2;

	int j = 0;
	for (int i = 0; i < 2; i++)
	{
		j = (j == dominant) ? (j+1) : j;
		for (int k = 0; k < 3; k++)
		{
			flatPoly->point[k].val[i] = poly->point[k]->val[j] - point->val[j];
		}
		j++;
	}
}

bool insideFlatPoly(poly2d* flatPoly)
{
	int numCrosses = 0;

	for (int i=0; i<3; i++)
	{
		if (testEdge(flatPoly, i))
		{
			numCrosses++;
		}
	}
	return (numCrosses == 1);	
}

bool testEdge(poly2d* flatPoly, int index)
{
	int next = (index + 1) % 3;
	if (((flatPoly->point[index].y > 0.f) && (flatPoly->point[next].y > 0.f)) ||
	   	((flatPoly->point[index].y < 0.f) && (flatPoly->point[next].y < 0.f)))
	{
		return false;
	}
	else
	{
		if ((flatPoly->point[index].x > 0.f) && (flatPoly->point[next].x > 0.f))
		{
			return true;
		}
		else
		{
			if ((flatPoly->point[index].x < 0.f) && (flatPoly->point[next].x < 0.f))
			{
				return false;
			}
			else
			{
				// It intersects, check if on positive side
				float k = -(flatPoly->point[index].y)/((flatPoly->point[next].y) - (flatPoly->point[index].y));
				float xin = (flatPoly->point[index].x) + (k * ((flatPoly->point[next].x) - (flatPoly->point[index].x)));
				return (xin > 0.f) ? true : false;
			}
		}
	}
}

// Debug
void	debugBuildPoly(polygon* poly, point3* p0, point3* p1, point3* p2, vec3* normal, color3f* color)
{
	// Points
	poly->point[0] = p0;
	poly->point[1] = p1;
	poly->point[2] = p2;
	// Normal
	vec3Cpy(&poly->normal, normal);
	// Color
	vec3Cpy(&poly->color, color);
	// D
	poly->d = vec3Dot(&poly->normal, poly->point[0]);
}
