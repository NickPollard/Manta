#include "src/common.h"
#include "src/matrix.h"
//--------------------------------------------------------
#include "src/vector.h"
#include <math.h>

void matrixIdent(matrix* m)
{
	// Rows at a time
	m->val[0][0] = 1.f;
	m->val[0][1] = 0.f;
	m->val[0][2] = 0.f;
	m->val[0][3] = 0.f;

	m->val[1][0] = 0.f;
	m->val[1][1] = 1.f;
	m->val[1][2] = 0.f;
	m->val[1][3] = 0.f;

	m->val[2][0] = 0.f;
	m->val[2][1] = 0.f;
	m->val[2][2] = 1.f;
	m->val[2][3] = 0.f;

	m->val[3][0] = 0.f;
	m->val[3][1] = 0.f;
	m->val[3][2] = 0.f;
	m->val[3][3] = 1.f;
}

void matrixVec3Rot(vec3* out, matrix* m, vec3* in)
{
	vec3 tmp;
	tmp.x = in->x * m->val[0][0] +
			in->y * m->val[0][1] +
			in->z * m->val[0][2];
	tmp.y = in->x * m->val[1][0] +
			in->y * m->val[1][1] +
			in->z * m->val[1][2];
	tmp.z = in->x * m->val[2][0] +
			in->y * m->val[2][1] +
			in->z * m->val[2][2];
	vec3Cpy(out, &tmp);
}

void matrixCpy(matrix* out, matrix* in)
{
	out->val[0][0] = in->val[0][0];
	out->val[0][1] = in->val[0][1];
	out->val[0][2] = in->val[0][2];
	out->val[0][3] = in->val[0][3];
                               
	out->val[1][0] = in->val[1][0];
	out->val[1][1] = in->val[1][1];
	out->val[1][2] = in->val[1][2];
	out->val[1][3] = in->val[1][3];
                               
	out->val[2][0] = in->val[2][0];
	out->val[2][1] = in->val[2][1];
	out->val[2][2] = in->val[2][2];
	out->val[2][3] = in->val[2][3];
                               
	out->val[3][0] = in->val[3][0];
	out->val[3][1] = in->val[3][1];
	out->val[3][2] = in->val[3][2];
	out->val[3][3] = in->val[3][3];
}

void rotMatrixFromVec3(matrix* out, vec3* dir, vec3* up)
{
	vec3 right;
	vec3Cross(&right, dir, up);
	out->val[0][0] = right.x;
	out->val[1][0] = right.y;
	out->val[2][0] = right.z;
	out->val[0][1] = up->x;
	out->val[1][1] = up->y;
	out->val[2][1] = up->z;
	out->val[0][2] = dir->x;
	out->val[1][2] = dir->y;
	out->val[2][2] = dir->z;
}

void invRotMatrixFromVec3(matrix* out, vec3* dir, vec3* up)
{
	vec3 right;
	vec3Cross(&right, dir, up);
	vec3Cpy((vec3*)&out->rows[0], &right);
	vec3Cpy((vec3*)&out->rows[1], up);
	vec3Cpy((vec3*)&out->rows[2], dir);
}

// Make a matrix to rotate around the Y axis
// Positive angle = clockwise rotation looking down
void matrixYAxisRot(matrix* m, float angle)
{
	float sinTh = sinf(angle);
	float cosTh = cosf(angle);
	matrixIdent(m);
	m->val[0][0] = cosTh;
	m->val[1][0] = 0.f;
	m->val[2][0] = sinTh;
	m->val[0][1] = 0.f;
	m->val[1][1] = 1.f;
	m->val[2][1] = 0.f;
	m->val[0][2] = -sinTh;
	m->val[1][2] = 0.f;
	m->val[2][2] = cosTh;
}
