#ifndef __MANTAMGR_H__
#define __MANTAMGR_H__

#include "src/filemanager_model.h"
#include "src/filemanager_scene.h"
#include "src/propMgr.h"

class RenderArea;
class Scene;
class View;

// Global Manager Pointers
extern FileManager_Model*	modelManager;
extern FileManager_Scene*	sceneManager;
extern PropMgr*				propManager;

class MantaMgr
{
	protected:
		RenderArea* mantaArea;
		Scene*		mantaScene;
		View*		mantaView;

	public:
		MantaMgr();
		virtual ~MantaMgr();

		void main(int argc, char** argv);
		void init();
		// The business
		bool tick();
};

#endif // __MANTAMGR_H__
