#ifndef __UNITTEST_H__
#define __UNITTEST_H__

class UnitTest
{
	protected:
	public:
		UnitTest();
		virtual ~UnitTest();

		void TestVectors();
		void TestSpeed();
};

#endif // __UNITTEST_H__
