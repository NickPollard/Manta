#ifndef __VECTOR_H__
#define __VECTOR_H__

extern const vec3 k_vec3_UP;

void	vec3Zero(vec3* vec);
bool	vec3IsUnit(vec3* vec);
void	vec3Set(vec3* vec, float x, float y, float z);
void	vec3Cpy(vec3* dst, vec3* src);
void	vec3Cross(vec3* dst, const vec3* v1, const vec3* v2);
float	vec3Dot(vec3* v1, vec3* v2);
void	vec3Scale(vec3* v, float f);
void	vec3Add(vec3* dst, vec3* src1, vec3* src2);
void	vec3AddScale(vec3* dst, vec3* src, float scale);
void	vec3Sub(vec3* dst, vec3* src1, vec3* src2);
float	vec3Len(vec3* v);
float	vec3LenSq(vec3* v);
float	vec3Manhattan(vec3* v);
void	vec3Unit(vec3* v);
void	vec3Reflect(vec3* reflectRay, vec3* inRay, vec3* normal);

#endif // __VECTOR_H__
